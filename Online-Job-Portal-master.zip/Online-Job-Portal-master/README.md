# Online Job Portal Project
Online Job Portal project is web application built using PHP, MySQL as backend and HTML JavaScript &amp; Bootstrap as Frontend technologies. Note that this software is developed as an academic project. <br/>
<b>A newer version (Work in progress) written using codeigniter framework can be obtained here: https://github.com/Sreelal-c/JobBoard</b>

<h3>Author:</h3> 
Sreelal C

<h2> License </h2>
Online-Job-Portal - A web application built on PHP HTML & javascript</br>
Copyright (C) 2016  Sreelal C

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
